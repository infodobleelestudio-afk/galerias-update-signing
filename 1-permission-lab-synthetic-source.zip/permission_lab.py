"""Prepared only. Never NAS. Separate owner-approved disposable Docker runner.
No workflow, secret, host user creation, sudo or installation. Docker itself is
privileged infrastructure; do not run without approval on a suitable runner.
"""
import argparse,json,pathlib,platform,shutil,subprocess,tempfile,uuid
BASE_IMAGE='python@sha256:0f086103b026048cc50cb5da25ec435c023c5241a83fc44daea593377abc61c4'
HERE=pathlib.Path(__file__).resolve().parent

def command(args,timeout=60):return subprocess.run(args,check=True,capture_output=True,text=True,timeout=timeout)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run-synthetic-docker',action='store_true');opt=parser.parse_args()
 if not opt.run_synthetic_docker:raise SystemExit('Prepared only. Separate approval and disposable Linux executor required, never NAS.')
 if not shutil.which('docker'):raise SystemExit('Docker unavailable; do not install or elevate')
 if platform.machine() not in ('x86_64','amd64'):raise SystemExit('fixed image needs Linux amd64 executor')
 info=json.loads(command(['docker','info','--format','{{json .}}']).stdout)
 if info.get('OSType')!='linux' or any(any(term in str(x).lower() for term in ('rootless','userns')) for x in info.get('SecurityOptions',[])):raise SystemExit('unsupported Docker identity remapping')
 # Pull is explicit before containers. Timeout can only leave a client-side
 # download, not an untracked running container from a docker run implicit pull.
 command(['docker','pull','--platform','linux/amd64',BASE_IMAGE],timeout=600)
 containers=set();errors=[]
 with tempfile.TemporaryDirectory(prefix='gallery-dac-synthetic-') as directory:
  root=pathlib.Path(directory);root.chmod(0o755);boot=root/'bootstrap';boot.mkdir(mode=0o755)
  for p in HERE.glob('*.py'):q=boot/p.name;shutil.copyfile(p,q);q.chmod(0o644)
  data=root/'fixture';data.mkdir(mode=0o755)
  def run_container(uid,args,*,caps=(),mounts=(),timeout=60):
   name='gallery-synth-'+uuid.uuid4().hex;containers.add(name)
   argv=['docker','run','--pull','never','--name',name,'--rm','--platform','linux/amd64','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges:true','--pids-limit','64','--memory','256m','--cpus','1','--user',uid,'--env','PYTHONDONTWRITEBYTECODE=1','--mount','type=bind,src='+str(boot)+',dst=/bootstrap,readonly']
   for cap in caps:argv+=['--cap-add',cap]
   for source,target,readonly in mounts:argv+=['--mount','type=bind,src='+str(source)+',dst='+target+(',readonly' if readonly else '')]
   try:return command(argv+[BASE_IMAGE]+args,timeout=timeout)
   finally:
    # Explicit name tracks even a docker client killed after server accepted run.
    # rm -f terminates and waits; preserve cleanup errors instead of masking cause.
    try:
     result=subprocess.run(['docker','rm','-f',name],capture_output=True,text=True,timeout=30)
     if result.returncode and 'No such container' not in result.stderr:errors.append('container cleanup failed: '+name)
     else:containers.discard(name)
    except (OSError,subprocess.TimeoutExpired):errors.append('container cleanup could not be verified: '+name)
  provision="""import os,pathlib
r=pathlib.Path('/fixture')
for name in ('commands-studio','commands-client','acks-studio','acks-client','decision'):
 p=r/name;p.mkdir(mode=0o750);p.chmod(0o750);os.chown(p,10001 if name.startswith('acks-') else 10002,1000)
p=r/'releases';p.mkdir(mode=0o750);p.chmod(0o750);os.chown(p,10002,1000)
for p in r.iterdir():
 expected=10001 if p.name.startswith('acks-') else 10002
 s=p.stat()
 if (s.st_uid,s.st_gid,s.st_mode&0o7777)!=(expected,1000,0o750):raise RuntimeError('provision directory ownership/mode')
"""
  original=None
  try:
   # Only fixed stdlib provisioning. No import of code from review package here.
   run_container('0:0',['python','-I','-c',provision],caps=('CHOWN','DAC_OVERRIDE'),mounts=((data,'/fixture',False),))
   def role_run(role,action,all_rw=False):
    uid='10002:1000' if role=='updater' else '10001:1000'
    mounts=[(data/'releases','/releases',False if all_rw else role!='updater'),(data/'decision','/control/decision',False if all_rw else role!='updater')]
    for name in ('studio','client'):
     if role=='updater' or role==name:
      mounts.extend([(data/('commands-'+name),'/control/commands-'+name,False if all_rw else role!='updater'),(data/('acks-'+name),'/control/acks-'+name,False if all_rw else role=='updater')])
    if action=='owner-ro':mounts=[(source,target,True) for source,target,ro in mounts]
    output=run_container(uid,['python','-B','/bootstrap/permission_probe.py',role,action],mounts=mounts)
    return json.loads(output.stdout)
   results=[role_run(role,'prepare',True) for role in ('updater','studio','client')]
   results.append(role_run('updater','publish'))
   results.append(role_run('updater','publish')) # replace existing command/lease files
   results.extend(role_run(role,'roles') for role in ('studio','client'))
   results.extend(role_run(role,'roles') for role in ('studio','client')) # replace existing ACK
   results.append(role_run('updater','read-acks'))
   for role in ('updater','studio','client'):
    results.append(role_run(role,'dac',True));results.append(role_run(role,'ro'));results.append(role_run(role,'owner-ro'))
   print(json.dumps({'synthetic_only':True,'scope':'DAC updater vs apps and role mount modes on this Linux/Docker only; NOT QNAP; studio/client same UID have NO DAC boundary','results':results},indent=2))
  except BaseException as e:original=e;raise
  finally:
   # No deleted host roots or glob patterns. Exposes this exact new random
   # directory only. Cleanup root has no package imports and one capability.
   clean="import pathlib,shutil;p=pathlib.Path('/fixture');[shutil.rmtree(x) if x.is_dir() else x.unlink() for x in p.iterdir()]"
   try:run_container('0:0',['python','-I','-c',clean],caps=('DAC_OVERRIDE',),mounts=((data,'/fixture',False),))
   except BaseException:
    if original is None:raise
    errors.append('fixture cleanup failed after primary error')
   if errors:
    if original is None:raise RuntimeError('; '.join(errors))
    original.add_note('; '.join(errors))
if __name__=='__main__':main()
