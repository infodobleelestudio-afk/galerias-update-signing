"""Disposable twoUID probe only. No secret/network. Invoked by reviewed lab."""
import errno,json,os,pathlib,sys,time
from mount_preflight import inspect_self,parse_mountinfo
from fixed_protocol import Channel,command,ack
from process_harness import durable
from stage_verified import stage_verified,verify_staged
ROLE,ACTION=sys.argv[1:3]
if ROLE not in ('updater','studio','client') or ACTION not in ('prepare','publish','roles','read-acks','dac','ro','owner-ro'):raise SystemExit('fixed probe')
uid=10002 if ROLE=='updater' else 10001
if (os.getuid(),os.getgid())!=(uid,1000):raise RuntimeError('unexpected identity')
observed={}
def info(path,owner=None,mode=None):
 p=pathlib.Path(path);s=p.stat();value={'uid':s.st_uid,'gid':s.st_gid,'mode':oct(s.st_mode&0o7777)};observed[str(p)]=value
 if owner is not None and (s.st_uid,s.st_gid,s.st_mode&0o7777)!=(owner,1000,mode):raise RuntimeError('observed owner/group/mode mismatch')
 return value
def reject(path,expected):
 try:
  fd=os.open(path,os.O_WRONLY|os.O_APPEND);os.close(fd)
 except OSError as e:
  if e.errno in (expected if isinstance(expected,tuple) else (expected,)):return
  raise
 raise RuntimeError('unexpected write permission')
def allowed(directory):
 p=pathlib.Path(directory)/('probe-'+ROLE);durable(p,{'synthetic':True},mode=0o640);info(p,uid,0o640);p.unlink()
root=pathlib.Path('/control');tx='a'*32
if ACTION=='prepare':
 names=('commands-studio','commands-client','decision') if ROLE=='updater' else ('acks-'+ROLE,)
 for name in names:
  p=root/name;p.chmod(0o2750);info(p,uid,0o2750)
elif ACTION=='publish':
 if ROLE!='updater':raise RuntimeError('publisher identity')
 state={'good':1,'active':1,'highest':1,'phase':'trial','tx':tx}
 durable(root/'decision/decision.json',state,mode=0o640)
 for role in ('studio','client'):
  c=Channel(root,role);durable(c.command_path,state,mode=0o640);durable(c.command_path.with_name('lease.json'),{'tx':tx,'phase':'trial','expires_ns':time.time_ns()+5_000_000_000},mode=0o640)
  info(c.command_path,10002,0o640);info(c.command_path.with_name('lease.json'),10002,0o640)
 stage_verified('/releases',1,{'app/example.py':b'# synthetic DAC probe only\n'})
 info('/control/decision/decision.json',10002,0o640)
elif ACTION=='roles':
 c=Channel(root,ROLE);state=c.read_command();command(state);effective,expired=c.effective_command(state)
 if effective['good']!=1:raise RuntimeError('unexpected protocol')
 for p in (c.command_path,c.command_path.with_name('lease.json'),root/'decision/decision.json'):info(p,10002,0o640)
 verify_staged('/releases',1,expected_owner_uid=10002);info('/releases/1/app/example.py',10002,0o644);info('/releases/1/READY.json',10002,0o644)
 observed['lease_evaluation']={'expired':expired,'effective_phase':effective['phase']}
 c.write_ack({'tx':state['tx'],'phase':'healthy','version':1,'gate':'trial'});info(c.ack_path,10001,0o640);allowed(c.ack_path.parent)
elif ACTION=='read-acks':
 for role in ('studio','client'):
  c=Channel(root,role);a=ack(json.loads(c.ack_path.read_bytes()),role)
  if a['tx']!=tx or a['version']!=1 or a['gate']!='trial':raise RuntimeError('ACK semantic mismatch')
  info(c.ack_path,10001,0o640)
elif ACTION=='owner-ro':
 # Owners would be allowed by DAC; these independent RO mounts must deny.
 targets=(root/'commands-studio/command.json',root/'decision/decision.json',pathlib.Path('/releases/1/app/example.py')) if ROLE=='updater' else (root/('acks-'+ROLE)/'ack.json',)
 for p in targets:reject(p,errno.EROFS)
elif ACTION=='dac':
 # All these mounts are RW in this variant, so EROFS cannot hide bad DAC.
 if ROLE=='updater':
  for role in ('studio','client'):reject(root/('acks-'+role)/'ack.json',errno.EACCES)
 else:
  for p in (root/('commands-'+ROLE)/'command.json',root/'decision/decision.json',pathlib.Path('/releases/1/app/example.py')):reject(p,errno.EACCES)
 targets=[root/('acks-'+role) for role in ('studio','client')] if ROLE=='updater' else [root/('commands-'+ROLE),root/'decision',pathlib.Path('/releases/1/app')]
 for directory in targets:
  try:fd=os.open(directory/'forbidden-create',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
  except OSError as e:
   if e.errno!=errno.EACCES:raise
  else:raise RuntimeError('directory create unexpectedly allowed')
  # Existing known files must also resist unlink and same-directory rename.
  existing=directory/('ack.json' if directory.name.startswith('acks-') else ('command.json' if directory.name.startswith('commands-') else ('decision.json' if directory.name=='decision' else 'example.py')))
  for operation in (lambda:os.rename(existing,directory/'forbidden-rename'),lambda:os.unlink(existing)):
   try:operation()
   except OSError as e:
    if e.errno!=errno.EACCES:raise
   else:raise RuntimeError('directory mutation unexpectedly allowed')
 # No cross-bind os.replace: EXDEV would test mount boundaries, not DAC.
 # Denied creation + rename/unlink in the target directory cover substitution.
 # Studio/client share UID: no claim of DAC isolation between those two roles.
elif ACTION=='ro':
 required={'/bootstrap':True,'/releases':ROLE!='updater','/control/decision':ROLE!='updater'}
 for role in ('studio','client'):
  if ROLE=='updater' or ROLE==role:required['/control/commands-'+role]=ROLE!='updater';required['/control/acks-'+role]=ROLE=='updater'
 inspect_self(required)
 actual=parse_mountinfo(pathlib.Path('/proc/self/mountinfo').read_text())
 actual_control={p for p in actual if p.startswith('/control/')}
 if actual_control!={p for p in required if p.startswith('/control/')}:raise RuntimeError('unexpected control mount set')
 if ROLE=='updater':
  for role in ('studio','client'):reject(root/('acks-'+role)/'ack.json',(errno.EACCES,errno.EROFS))
 else:
  reject(root/('commands-'+ROLE)/'command.json',(errno.EACCES,errno.EROFS));reject('/releases/1/app/example.py',(errno.EACCES,errno.EROFS))
  other='client' if ROLE=='studio' else 'studio'
  for prefix in ('commands-','acks-'):
   if (root/(prefix+other)).exists():raise RuntimeError('unexpected other-role mount')
print(json.dumps({'synthetic_only':True,'role':ROLE,'action':ACTION,'uid':uid,'gid':os.getgid(),'observed':observed,'result':'pass'}))
