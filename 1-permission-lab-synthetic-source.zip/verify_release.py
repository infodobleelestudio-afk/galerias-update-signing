"""Offline prototype only. Fixed trusted config is outside downloaded releases.
No networking, process control, NAS paths or production trust key in this module.
"""
import base64,hashlib,io,json,re,stat,zipfile
from pathlib import PurePosixPath
APP='doble-ele-galerias'
MAX_ARCHIVE=32*1024*1024
MAX_EXPANDED=96*1024*1024
MAX_FILES=256
SUFFIXES={'.py','.js','.css','.html','.png','.svg','.whl','.lock','.txt'}
class Rejected(ValueError):pass

def unique(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise Rejected('duplicate JSON field')
  out[k]=v
 return out

def safe_path(value):
 if not isinstance(value,str) or not re.fullmatch(r'app/[A-Za-z0-9_./-]{1,220}',value):raise Rejected('path outside code')
 p=PurePosixPath(value)
 if str(p)!=value or any(s in ('','..','.') or s.startswith('.') for s in value.split('/')) or p.suffix not in SUFFIXES:raise Rejected('unsupported code path')
 if any(x in value for x in ('bootstrap','supervisor','trust-root','manifest.json','private.key')):raise Rejected('immutable boundary')
 return value

def verify(manifest_bytes,signature_b64,archive_bytes,public_key,highest_sequence,bootstrap=1):
 from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
 if len(manifest_bytes)>128*1024 or len(archive_bytes)>MAX_ARCHIVE:raise Rejected('download bound')
 try:Ed25519PublicKey.from_public_bytes(public_key).verify(base64.b64decode(signature_b64,validate=True),manifest_bytes)
 except Exception as e:raise Rejected('signature') from e
 return validate_payload(manifest_bytes,archive_bytes,highest_sequence,bootstrap)

def validate_payload(manifest_bytes,archive_bytes,highest_sequence,bootstrap=1):
 if len(manifest_bytes)>128*1024 or len(archive_bytes)>MAX_ARCHIVE:raise Rejected('download bound')
 try:m=json.loads(manifest_bytes,object_pairs_hook=unique)
 except Exception as e:raise Rejected('manifest JSON') from e
 if set(m)!={'app','sequence','schema','bootstrap','zip_sha256','files'}:raise Rejected('manifest fields')
 if m['app']!=APP or m['schema']!='gallery-schema22' or m['bootstrap']!=bootstrap:raise Rejected('incompatible application/schema/bootstrap')
 if type(m['sequence'])is not int or m['sequence']<=highest_sequence:raise Rejected('replay/downgrade')
 if m['zip_sha256']!=hashlib.sha256(archive_bytes).hexdigest():raise Rejected('archive hash')
 files=m['files']
 if not isinstance(files,dict) or not 1<=len(files)<=MAX_FILES:raise Rejected('file count')
 for p,h in files.items():
  safe_path(p)
  if not isinstance(h,str) or not re.fullmatch('[0-9a-f]{64}',h):raise Rejected('file hash format')
 result={};expanded=0
 try:
  with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
   for i in z.infolist():
    name=safe_path(i.filename);mode=i.external_attr>>16
    if name in result or i.is_dir() or (stat.S_IFMT(mode) not in (0,stat.S_IFREG)) or i.flag_bits&1:raise Rejected('duplicate/link/directory/encrypted member')
    expanded+=i.file_size
    if expanded>MAX_EXPANDED or i.file_size>MAX_ARCHIVE or len(result)>=MAX_FILES:raise Rejected('expanded bound')
    b=z.read(i)
    if len(b)!=i.file_size or hashlib.sha256(b).hexdigest()!=files.get(name):raise Rejected('file integrity')
    result[name]=b
 except (zipfile.BadZipFile,RuntimeError,KeyError) as e:raise Rejected('ZIP') from e
 if set(result)!=set(files):raise Rejected('missing member')
 return m,result
