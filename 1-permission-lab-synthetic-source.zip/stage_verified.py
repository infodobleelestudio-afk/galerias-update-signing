"""Offline staging implementation, not wired to a production trust policy.
Input is an already verified mapping, never a ZIP extraction API.
Root must be provisioned private to the updater, not shared with app writers.
"""
import fcntl,hashlib,json,os,pathlib,shutil,stat,uuid,warnings
from verify_release import safe_path
class StageRejected(ValueError):pass

def syncdir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(fd)
 finally:os.close(fd)

def require_private_root(root):
 root=pathlib.Path(root).absolute();s=root.lstat()
 if root.resolve()!=root or not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o022:raise StageRejected('root must be an owned non-writable-by-others real directory')
 return root

def stage_verified(root,sequence,files,inject=None):
 root=require_private_root(root)
 if type(sequence)is not int or sequence<1 or not isinstance(files,dict) or not 1<=len(files)<=256:raise StageRejected('arguments')
 if any(not isinstance(b,bytes) for b in files.values()) or sum(map(len,files.values()))>96*1024*1024:raise StageRejected('expanded bound')
 for name,b in files.items():
  safe_path(name)
  if not isinstance(b,bytes):raise StageRejected('bytes required')
 lockfd=os.open(root/'.stage.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
 stage=None
 try:
  fcntl.flock(lockfd,fcntl.LOCK_EX)
  dest=root/str(sequence)
  if dest.exists() or dest.is_symlink():
   existing=verify_staged(root,sequence,expected_owner_uid=os.getuid())
   expected={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
   if existing['files']!=expected:raise StageRejected('sequence directory differs from verified payload')
   return dest
  stage=root/('.staging-'+uuid.uuid4().hex);stage.mkdir(mode=0o700);syncdir(root)
  if inject:inject('created')
  for name,b in sorted(files.items()):
   p=stage/name;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
   fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
   try:
    with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
   except Exception:raise
   if inject:inject('file')
  # A clean readback, not trust in write return values.
  observed={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.rglob('*') if p.is_file()}
  expected={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
  if observed!=expected:raise StageRejected('readback mismatch')
  marker=json.dumps({'sequence':sequence,'files':expected},sort_keys=True,separators=(',',':')).encode()
  with open(stage/'READY.json','xb') as f:f.write(marker);f.flush();os.fsync(f.fileno())
  for p in sorted((p for p in stage.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):os.chmod(p,0o755);syncdir(p)
  for p in stage.rglob('*'):
   if p.is_file():
    os.chmod(p,0o644)
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    try:os.fsync(fd)
    finally:os.close(fd)
  os.chmod(stage,0o755);syncdir(stage)
  if inject:inject('before-rename')
  os.rename(stage,dest);stage=None;syncdir(root)
  return dest
 finally:
  if stage is not None:
   try:shutil.rmtree(stage)
   except OSError:warnings.warn('staging cleanup incomplete; explicit private cleanup required',RuntimeWarning)
  os.close(lockfd)

def require_read_root(root,expected_owner_uid):
 root=pathlib.Path(root).absolute();s=root.lstat()
 if type(expected_owner_uid)is not int or expected_owner_uid<0 or root.resolve()!=root or not stat.S_ISDIR(s.st_mode) or s.st_uid!=expected_owner_uid or s.st_mode&0o022:raise StageRejected('unexpected release root owner/mode')
 return root

def verify_staged(root,sequence,expected_owner_uid=None):
 # Caller pins expected owner in bootstrap policy, not from the downloaded ZIP.
 # None is only a legacy local-fixture convenience, never deployment policy.
 root=require_read_root(root,os.getuid() if expected_owner_uid is None else expected_owner_uid);dest=root/str(sequence)
 if dest.is_symlink() or not dest.is_dir():raise StageRejected('not a release')
 marker=dest/'READY.json'
 if marker.is_symlink() or not marker.is_file():raise StageRejected('no ready marker')
 m=json.loads(marker.read_bytes())
 if m.get('sequence')!=sequence or not isinstance(m.get('files'),dict):raise StageRejected('bad marker')
 observed={}
 for p in dest.rglob('*'):
  if p.is_symlink():raise StageRejected('symlink')
  if p.is_file() and p!=marker:
   name=str(p.relative_to(dest));safe_path(name);observed[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 if observed!=m['files']:raise StageRejected('staged data changed')
 return m
