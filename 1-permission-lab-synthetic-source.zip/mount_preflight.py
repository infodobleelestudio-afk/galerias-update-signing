"""Read-only mountinfo preflight primitive. Does not mount, remount or inspect
credentials. Mountinfo alone cannot establish trusted host source identity.
That must be checked against the initial deployment metadata separately.
"""
import os,pathlib,re
class MountRejected(RuntimeError):pass

def unescape(s):
 def replace(m):
  code=m.group(1)
  if code not in ('040','011','012','134'):raise MountRejected('unexpected mount escape')
  return chr(int(code,8))
 return re.sub(r'\\([0-7]{3})',replace,s)

def parse_mountinfo(text):
 if not isinstance(text,str) or len(text)>2*1024*1024:raise MountRejected('mountinfo bounds')
 mounts={}
 for line in text.splitlines():
  parts=line.split(' ')
  try:dash=parts.index('-')
  except ValueError:raise MountRejected('mountinfo separator')
  if len(parts)<10 or dash<6 or len(parts)<dash+4:raise MountRejected('mountinfo structure')
  target=unescape(parts[4]);root=unescape(parts[3])
  if not target.startswith('/') or target in mounts:raise MountRejected('ambiguous mount target')
  flags=set(parts[5].split(','))
  if ('ro' in flags)==('rw' in flags):raise MountRejected('mount mode unavailable')
  mounts[target]={'target':target,'root':root,'readonly':'ro' in flags,'filesystem':parts[dash+1],'flags':sorted(flags)}
 return mounts

def validate_mounts(text,required):
 # Required is fixed bootstrap policy, never taken from a release manifest.
 if not isinstance(required,dict) or not required:raise MountRejected('required mounts missing')
 mounts=parse_mountinfo(text)
 for target,readonly in required.items():
  if not isinstance(target,str) or not target.startswith('/') or type(readonly)is not bool:raise MountRejected('policy')
  m=mounts.get(target)
  if m is None or m['readonly']!=readonly:raise MountRejected('required mount mode mismatch')
  for nested,row in mounts.items():
   if nested!=target and nested.startswith(target.rstrip('/')+'/') and nested not in required:raise MountRejected('unexpected nested mount')
 return True

def inspect_self(required):
 # Called only inside the relevant container; cannot certify another process.
 text=pathlib.Path('/proc/self/mountinfo').read_text()
 validate_mounts(text,required)
 for target in required:
  p=pathlib.Path(target)
  if p.is_symlink() or p.resolve()!=p:raise MountRejected('mount target symlink')
 return True
