"""Offline synthetic harness. Not NAS bootstrap. No downloaded code is executed.
All executable children are fixed test fixtures created by this harness.
"""
import json,os,pathlib,signal,subprocess,sys,time,urllib.request,uuid
ROLES=('studio','client')

def durable(path,value,mode=0o600):
 path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_name(path.name+'.tmp-'+uuid.uuid4().hex)
 fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
 os.fchmod(fd,mode)
 try:
  with os.fdopen(fd,'w') as f:json.dump(value,f);f.flush();os.fsync(f.fileno())
  os.replace(tmp,path)
  fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
  try:os.fsync(fd)
  finally:os.close(fd)
 finally:
  try:tmp.unlink()
  except FileNotFoundError:pass

def read(path):
 try:return json.loads(pathlib.Path(path).read_text())
 except FileNotFoundError:return None

def http(port,path,post=False):
 req=urllib.request.Request('http://127.0.0.1:'+str(port)+path,data=b'' if post else None)
 with urllib.request.urlopen(req,timeout=.4) as r:return json.load(r)

def fixture(port,version,busy,fail):
 from http.server import HTTPServer,BaseHTTPRequestHandler
 started=time.monotonic();draining=False
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def do_POST(self):
   nonlocal draining
   if self.path!='/drain':self.send_error(404);return
   draining=True;self.reply({'drained':time.monotonic()-started>=busy})
  def do_GET(self):
   if self.path!='/health':self.send_error(404);return
   self.reply({'version':version,'healthy':not fail,'draining':draining})
  def reply(self,obj):
   b=json.dumps(obj).encode();self.send_response(200);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 HTTPServer(('127.0.0.1',port),Handler).serve_forever()

def supervise(root,role,port):
 root=pathlib.Path(root);proc=None;running=None;stopping=False;last_phase=None
 def stop(*a):
  nonlocal stopping
  stopping=True
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 def terminate():
  nonlocal proc
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=1)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
  proc=None
 try:
  while not stopping:
   cmd=read(root/'command.json')
   if cmd:
    phase=cmd['phase'];wanted=cmd['active'];tx=cmd['tx']
    if phase=='draining':
     drained=False
     try:drained=http(port,'/drain',True)['drained']
     except Exception:pass
     durable(root/(role+'.json'),{'tx':tx,'phase':'drained' if drained else 'busy','version':running})
    else:
     if proc is None or proc.poll() is not None or wanted!=running or last_phase=='draining':
      terminate();policy=read(root/'fixture-policy.json') or {};spec=policy.get(str(wanted),{}).get(role,{})
      proc=subprocess.Popen([sys.executable,__file__,'fixture',str(port),str(wanted),str(spec.get('busy',0)),str(int(spec.get('fail',False)))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
      running=wanted
     healthy=False
     try:h=http(port,'/health');healthy=h['version']==wanted and h['healthy']
     except Exception:pass
     durable(root/(role+'.json'),{'tx':tx,'phase':'healthy' if healthy else 'unhealthy','version':running})
    last_phase=phase
   time.sleep(.05)
 finally:terminate()

def validate_journal(state):
 if not isinstance(state,dict) or set(state)!={'good','active','highest','phase','tx'}:raise ValueError('invalid journal fields')
 if any(type(state[k])is not int or not 1<=state[k]<=2**63-1 for k in ('good','active','highest')):raise ValueError('invalid journal version')
 if max(state['good'],state['active'])>state['highest']:raise ValueError('journal version order')
 if state['phase'] not in ('idle','draining','trial','commit','rollback') or not isinstance(state['tx'],str) or len(state['tx'])!=32 or any(c not in '0123456789abcdef' for c in state['tx']):raise ValueError('invalid journal state')
 if state['phase'] in ('idle','draining','rollback') and state['active']!=state['good']:raise ValueError('journal active/good mismatch')
 if state['phase']=='commit' and not state['active']==state['good']:raise ValueError('commit decision missing')
 return state

class Controller:
 def __init__(self,root,initial=1,initialize=False):
  self.root=pathlib.Path(root);self.root.mkdir(parents=True,exist_ok=True)
  journal=read(self.root/'journal.json');anchor=read(self.root/'highest.json')
  if journal is None:
   if not initialize or anchor is not None:raise RuntimeError('missing deployment journal; explicit recovery required')
   if type(initial)is not int or initial<1:raise ValueError('initial version')
   self.state={'good':initial,'active':initial,'highest':initial,'phase':'idle','tx':uuid.uuid4().hex}
  else:
   self.state=validate_journal(journal)
   if not isinstance(anchor,dict) or set(anchor)!={'highest'} or type(anchor['highest'])is not int or not self.state['highest']<=anchor['highest']<=2**63-1:raise RuntimeError('missing/invalid monotonic anchor; recovery required')
   self.state['highest']=anchor['highest']
  # Before commit, recover to last-good. Once commit is durable, recover forward:
  # the new code may already have served writes and must not be silently undone.
  if self.state['phase'] not in ('idle','commit'):self.state.update(active=self.state['good'],phase='rollback',tx=uuid.uuid4().hex)
  self.save()
 def save_journal(self):
  validate_journal(self.state)
  durable(self.root/'highest.json',{'highest':self.state['highest']})
  durable(self.root/'journal.json',self.state)
 def save(self):
  self.save_journal()
  durable(self.root/'command.json',self.state)
 def all_ack(self,phase,version):
  return all((lambda a: a is not None and a.get('tx')==self.state['tx'] and a.get('phase')==phase and a.get('version')==version)(read(self.root/(r+'.json'))) for r in ROLES)
 def wait(self,phase,version,timeout):
  end=time.monotonic()+timeout
  while time.monotonic()<end:
   if self.all_ack(phase,version):return True
   time.sleep(.04)
  return False
 def recover(self,timeout=3):
  phase='serving' if self.state['phase']=='commit' else 'healthy'
  if not self.wait(phase,self.state['good'],timeout):raise RuntimeError('recovery incomplete; maintenance/operator attention required')
  self.state.update(active=self.state['good'],phase='idle');self.save()
 def repair_forward(self,sequence,timeout=3):
  if self.state['phase'] not in ('commit','rollback'):raise ValueError('forward repair requires incomplete committed recovery')
  return self.deploy_verified(sequence,timeout=timeout,require_serving=True,_repair=True)
 def deploy_verified(self,sequence,timeout=3,interrupt_at=None,require_serving=False,_repair=False):
  if (self.state['phase']!='idle' and not (_repair and self.state['phase'] in ('commit','rollback'))) or type(sequence)is not int or sequence<=self.state['highest']:raise ValueError('busy/replay')
  self.state.update(highest=sequence,phase='draining',tx=uuid.uuid4().hex);self.save()
  if interrupt_at=='draining':return 'interrupted'
  if not self.wait('drained',self.state['active'],timeout):
   if _repair:self.state.update(active=self.state['good'],phase='commit');self.save();return 'repair-drain-timeout'
   self.rollback(timeout);return 'drain-timeout'
  self.state.update(active=sequence,phase='trial');self.save()
  if interrupt_at=='trial':return 'interrupted'
  if not self.wait('healthy',sequence,timeout):
   if _repair:
    self.state.update(active=self.state['good'],phase='commit');self.save();return 'repair-trial-failed'
   self.rollback(timeout);return 'rolled-back'
  if require_serving:
   self.state.update(good=sequence,phase='commit');self.save()
   if interrupt_at=='commit':return 'interrupted'
   if not self.wait('serving',sequence,timeout):return 'commit-incomplete'
  self.state.update(good=sequence,phase='idle');self.save();return 'committed'
 def rollback(self,timeout):
  if self.state['phase']=='commit':raise RuntimeError('commit is durable; automatic rollback forbidden after serving may begin')
  self.state.update(active=self.state['good'],phase='rollback',tx=uuid.uuid4().hex);self.save();self.recover(timeout)

if __name__=='__main__':
 if sys.argv[1]=='fixture':fixture(int(sys.argv[2]),int(sys.argv[3]),float(sys.argv[4]),bool(int(sys.argv[5])))
 elif sys.argv[1]=='supervisor':supervise(sys.argv[2],sys.argv[3],int(sys.argv[4]))
