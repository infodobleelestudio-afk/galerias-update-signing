"""Fixed filesystem control protocol. No paths, URLs, shell or executable names
in messages. Production separation requires per-role mounts/permissions, not
implemented by changing local folder modes alone. Same-UID child may forge its
own ACK: normal-failure recovery only, not hostile-child isolation.
"""
import json,os,pathlib,re,stat,time
from process_harness import durable,Controller
ROLES=('studio','client')
PHASES={'idle','draining','trial','commit','rollback'}

def integer(x):return type(x)is int and 1<=x<=2**63-1

def command(c):
 if not isinstance(c,dict) or set(c)!={'good','active','highest','phase','tx'}:raise ValueError('fixed command fields')
 if not all(integer(c[k]) for k in ('good','active','highest')) or max(c['good'],c['active'])>c['highest']:raise ValueError('version bounds')
 if c['phase'] not in PHASES or not isinstance(c['tx'],str) or not re.fullmatch('[0-9a-f]{32}',c['tx']):raise ValueError('phase or transaction')
 if c['phase']=='trial' and c['active']!=c['highest']:raise ValueError('candidate not highest')
 if c['phase'] in ('idle','draining','rollback','commit') and c['active']!=c['good']:raise ValueError('active/good mismatch')
 return c

def ack(a,role):
 if role not in ROLES or not isinstance(a,dict) or set(a)!={'tx','phase','version','gate','role'}:raise ValueError('fixed ACK fields')
 if a['role']!=role or not integer(a['version']) or not isinstance(a['tx'],str) or not re.fullmatch('[0-9a-f]{32}',a['tx']):raise ValueError('ACK identity')
 allowed={'busy','drained','healthy','unhealthy','serving','fallback'}
 if a['phase'] not in allowed or a['gate'] not in {'trial','serving','draining'}:raise ValueError('ACK state')
 if a['phase']=='drained' and a['gate']!='draining' or a['phase']=='serving' and a['gate']!='serving':raise ValueError('ACK inconsistent gate')
 return a

def unique(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate control field')
  d[k]=v
 return d

def safe_read(path):
 p=pathlib.Path(path)
 if p.parent.is_symlink() or p.is_symlink():raise ValueError('control symlink')
 try:fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 except FileNotFoundError:return None
 try:
  s=os.fstat(fd)
  if not stat.S_ISREG(s.st_mode) or s.st_size>4096:raise ValueError('control file bound')
  with os.fdopen(fd,'rb') as f:fd=None;b=f.read(4097)
  if len(b)>4096:raise ValueError('control file bound')
  return json.loads(b,object_pairs_hook=unique)
 finally:
  if fd is not None:os.close(fd)

class Channel:
 def __init__(self,root,role):
  if role not in ROLES:raise ValueError('fixed role required')
  self.root=pathlib.Path(root);self.role=role
  self.command_path=self.root/('commands-'+role)/'command.json'
  self.ack_path=self.root/('acks-'+role)/'ack.json'
 def read_command(self):
  c=safe_read(self.command_path)
  return command(c) if c is not None else None
 def lease_state(self,c):
  try:lease=safe_read(self.command_path.with_name('lease.json'))
  except (ValueError,OSError):return 'invalid'
  if not isinstance(lease,dict) or set(lease)!={'tx','phase','expires_ns'} or lease['tx']!=c['tx'] or lease['phase']!=c['phase'] or type(lease['expires_ns'])is not int:return 'invalid'
  remaining=lease['expires_ns']-time.time_ns()
  if remaining>10_000_000_000:return 'invalid'
  return 'fresh' if remaining>0 else 'expired'
 def expired(self,c):return self.lease_state(c)!='fresh'
 def effective_command(self,c):
  if c['phase']=='idle':return c,False
  lease_state=self.lease_state(c)
  if lease_state=='fresh':return c,False
  # One common durable decision precedes either role's commit command. Reading
  # only an expired per-role command could roll one role back after the other
  # had already served writes during a partial command publication.
  try:d=command(safe_read(self.root/'decision'/'decision.json'))
  except (ValueError,OSError,TypeError):return {**c,'phase':'draining'},True
  if d['tx']!=c['tx']:return {**c,'phase':'draining'},True
  # During partial publication lease can already describe the newer decision
  # while command still describes trial. Only a real expired matching lease
  # of command OR common decision permits fallback; invalid/fresh stays shut.
  if lease_state!='expired' and self.lease_state(d)!='expired':return {**c,'phase':'draining'},True
  return {**d,'active':d['good'],'phase':'idle'},True
 def recovery_without_command(self):
  try:d=command(safe_read(self.root/'decision'/'decision.json'))
  except (ValueError,OSError,TypeError):return None
  # Missing command is not proof the updater died. A fresh matching lease
  # keeps the barrier shut even though the decision identifies a valid good.
  try:lease=safe_read(self.command_path.with_name('lease.json'))
  except (OSError,ValueError):return None
  if not isinstance(lease,dict) or set(lease)!={'tx','phase','expires_ns'} or lease['tx']!=d['tx'] or lease['phase']!=d['phase'] or type(lease['expires_ns'])is not int or lease['expires_ns']>time.time_ns():return None
  return {**d,'active':d['good'],'phase':'idle'}
 def write_ack(self,value):durable(self.ack_path,ack({**value,'role':self.role},self.role),mode=0o640)

def provision_local_fixture(root):
 root=pathlib.Path(root);root.mkdir(mode=0o750,exist_ok=True)
 decision=root/'decision';decision.mkdir(mode=0o2750,exist_ok=True);decision.chmod(0o2750)
 for role in ROLES:
  for part in ('commands-','acks-'):
   directory=root/(part+role);directory.mkdir(mode=0o2750,exist_ok=True);directory.chmod(0o2750)

class FixedController(Controller):
 def __init__(self,root,initial=1,initialize=False):
  self.control=pathlib.Path(root)/'control';provision_local_fixture(self.control);super().__init__(root,initial,initialize=initialize)
 def save(self):
  command(self.state);self.save_journal()
  durable(self.control/'decision'/'decision.json',self.state,mode=0o640)
  self.refresh_commands()
 def refresh_commands(self):
  for role in ROLES:
   channel=Channel(self.control,role)
   durable(channel.command_path.with_name('lease.json'),{'tx':self.state['tx'],'phase':self.state['phase'],'expires_ns':time.time_ns()+5_000_000_000},mode=0o640)
   durable(channel.command_path,self.state,mode=0o640)
 def wait(self,phase,version,timeout):
  end=time.monotonic()+timeout;last=0
  while time.monotonic()<end:
   if time.monotonic()-last>.2:self.refresh_commands();last=time.monotonic()
   if self.all_ack(phase,version):return True
   time.sleep(.04)
  return False
 def all_ack(self,phase,version):
  for role in ROLES:
   try:
    ack_path=Channel(self.control,role).ack_path
    if not 0<=time.time()-ack_path.stat().st_mtime<=2:return False
    a=safe_read(ack_path)
    if a is None:return False
    ack(a,role)
   except (ValueError,OSError):return False
   if a['tx']!=self.state['tx'] or a['phase']!=phase or a['version']!=version:return False
   expected_gate='draining' if phase=='drained' else ('serving' if phase=='serving' or self.state['phase']=='idle' else 'trial')
   if a['gate']!=expected_gate:return False
  return True
